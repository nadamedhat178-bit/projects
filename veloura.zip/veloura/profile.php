<?php
include 'config.php';

if(!isset($_SESSION['user_id'])){
header("Location: login.php");
exit();
}

$user_id = (int)$_SESSION['user_id'];

/* USER INFO */
$q = mysqli_query($conn,"SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($q);

/* ORDERS */
$orders = mysqli_query($conn,"
SELECT * FROM orders
WHERE user_id='$user_id'
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Profile | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/profile.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ YOUR VELOURA ACCOUNT ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<?php if($isLoggedIn){ ?>

<a href="profile.php">Profile</a>
<a href="favorites.php">Favorites</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>
<a href="cart.php">Cart</a>

<div class="icons">
<span><i class="fas fa-search"></i></span>
<span><i class="far fa-heart"></i></span>
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="far fa-user"></i></span>
</div>
</nav>
</header>

<section class="profile-page">

<div class="profile-grid">

<!-- LEFT -->
<div class="profile-card">

<div class="profile-avatar">
<i class="fas fa-user"></i>
</div>

<h2><?php echo $user['full_name']; ?></h2>

<p class="profile-email">
<?php echo $user['email']; ?>
</p>

<div class="profile-stats">

<div>
<span><?php echo mysqli_num_rows($orders); ?></span>
<small>Orders</small>
</div>


</div>

<a href="shop.php" class="btn profile-btn">
Continue Shopping
</a>
<a href="editprofile.php" class="btn profile-btn">
Edit Profile
</a>
<a href="logout.php" class="logout-btn">
Logout
</a>

</div>

<!-- RIGHT -->
<div class="orders-card">

<h2>Recent Orders</h2>

<?php if(mysqli_num_rows($orders) > 0){ ?>

<?php while($o = mysqli_fetch_assoc($orders)){ ?>

<div class="order-row">

<div>
<h3>Order #<?php echo $o['id']; ?></h3>
<p>Placed Successfully</p>
</div>

<div class="order-price">
$<?php echo number_format($o['total_price'],2); ?>
</div>

</div>

<?php } ?>

<?php }else{ ?>

<div class="no-orders">
<i class="fas fa-box-open"></i>
<p>No orders yet.</p>
<a href="shop.php" class="btn">Start Shopping</a>
</div>

<?php } ?>

</div>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>