<?php
include 'config.php';

$isLoggedIn = isset($_SESSION['user_id']);

$id = (int)$_GET['id'];

/* FAVORITES TOGGLE */
if(isset($_GET['fav']) && $isLoggedIn){

$user = (int)$_SESSION['user_id'];

$check = mysqli_query($conn,"
SELECT id FROM favorites
WHERE user_id='$user' AND product_id='$id'
");

if(mysqli_num_rows($check) > 0){

mysqli_query($conn,"
DELETE FROM favorites
WHERE user_id='$user' AND product_id='$id'
");

}else{

mysqli_query($conn,"
INSERT INTO favorites(user_id,product_id)
VALUES('$user','$id')
");

}

header("Location: product.php?id=$id");
exit();
}

/* GET PRODUCT */
$q = mysqli_query($conn,"SELECT * FROM products WHERE id='$id'");
$p = mysqli_fetch_assoc($q);

if(!$p){
header("Location: shop.php");
exit();
}

/* CHECK IF FAVORITED */
$fav = 0;

if($isLoggedIn){

$user = (int)$_SESSION['user_id'];

$chk = mysqli_query($conn,"
SELECT id FROM favorites
WHERE user_id='$user' AND product_id='$id'
");

$fav = mysqli_num_rows($chk);
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo $p['product_name']; ?> | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/product.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ LIMITED EDITION LUXURY COLLECTION ✨</section>

<header>

<h1>VELOURA</h1>

<nav>

<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<a href="cart.php">Cart</a>

<?php if($isLoggedIn){ ?>

<a href="favorites.php">Favorites</a>
<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>

<div class="icons">

<span onclick="location.href='shop.php'">
<i class="fas fa-search"></i>
</span>

<?php if($isLoggedIn){ ?>

<span onclick="location.href='favorites.php'">
<i class="far fa-heart"></i>
</span>

<span onclick="location.href='profile.php'">
<i class="far fa-user"></i>
</span>

<?php }else{ ?>

<span onclick="location.href='login.php'">
<i class="far fa-heart"></i>
</span>

<span onclick="location.href='login.php'">
<i class="far fa-user"></i>
</span>

<?php } ?>

<span onclick="location.href='cart.php'">
<i class="fas fa-shopping-bag"></i>
</span>

</div>

</nav>

</header>

<section class="product-page">

<div class="product-wrap">

<!-- IMAGE -->
<div class="product-image-box">

<?php if($isLoggedIn){ ?>

<a href="product.php?id=<?php echo $id; ?>&fav=1" class="heart big-heart">

<?php if($fav){ ?>
<i class="fas fa-heart"></i>
<?php }else{ ?>
<i class="far fa-heart"></i>
<?php } ?>

</a>

<?php }else{ ?>

<a href="login.php" class="heart big-heart">
<i class="far fa-heart"></i>
</a>

<?php } ?>

<img
src="images/<?php echo $p['image']; ?>"
alt="<?php echo $p['product_name']; ?>">

</div>

<!-- INFO -->
<div class="product-info-box">

<h2><?php echo $p['product_name']; ?></h2>

<div class="stars">
<i class="fas fa-star"></i>
<i class="fas fa-star"></i>
<i class="fas fa-star"></i>
<i class="fas fa-star"></i>
<i class="fas fa-star-half-alt"></i>
<span>(124 Reviews)</span>
</div>

<p class="product-price">
$<?php echo number_format($p['price'],2); ?>
</p>

<p class="product-desc">
<?php echo $p['description']; ?>
</p>

<div class="luxury-points">
<div>💎 Premium Materials</div>
<div>🚚 Fast Shipping</div>
<div>🔒 Secure Checkout</div>
</div>

<form method="post" action="cart.php" class="cart-form">

<input
type="hidden"
name="id"
value="<?php echo $p['id']; ?>">

<div class="qty-box">

<button type="button" onclick="minusQty()">−</button>

<input
type="number"
id="qty"
name="qty"
value="1"
min="1">

<button type="button" onclick="plusQty()">+</button>

</div>

<button class="login-btn add-cart-btn">
<i class="fas fa-shopping-bag"></i>
Add To Cart
</button>

</form>

<div class="login-links">
<a href="shop.php">← Continue Shopping</a>
</div>

</div>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

<script src ='product.js'></script>


</body>
</html>