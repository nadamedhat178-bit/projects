const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');

let current = 0;
let interval;

function showSlide(i){
slides.forEach((slide,index)=>{
slide.classList.toggle('active', index === i);
dots[index].classList.toggle('active', index === i);
});
current = i;
}

function autoSlide(){
interval = setInterval(()=>{
current = (current + 1) % slides.length;
showSlide(current);
},5000);
}

dots.forEach((dot,i)=>{
dot.addEventListener('click',()=>{
clearInterval(interval);
showSlide(i);
autoSlide();
});
});

const hero = document.querySelector('.hero');

hero.addEventListener('mouseenter',()=>clearInterval(interval));
hero.addEventListener('mouseleave',autoSlide);

autoSlide();