<?php
include '../config.php';

/* OPTIONAL ADMIN CHECK
if(!isset($_SESSION['admin'])){
header("Location:login.php");
exit();
}
*/

/* UPDATE STATUS */
if(isset($_GET['complete'])){

$id = (int)$_GET['complete'];

mysqli_query($conn,"
UPDATE orders
SET status='Completed'
WHERE id='$id'
");

header("Location:orders.php");
exit();
}

if(isset($_GET['cancel'])){

$id = (int)$_GET['cancel'];

mysqli_query($conn,"
UPDATE orders
SET status='Cancelled'
WHERE id='$id'
");

header("Location:orders.php");
exit();
}

/* GET ORDERS */
$q = mysqli_query($conn,"
SELECT orders.*, users.full_name, users.email
FROM orders
LEFT JOIN users ON users.id = orders.user_id
ORDER BY orders.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Orders | Veloura Admin</title>


<link rel="stylesheet" href="../css/global.css">
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ ORDER MANAGEMENT PANEL ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="add_product.php">Add Product</a>
<a href="manage_users.php">Users</a>
<a href="manage_products.php">Products</a>
<a href="orders.php">Orders</a>
<a href="../index.php">Website</a>
<a href="../logout.php">Logout</a>

<div class="icons">
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="fas fa-chart-line"></i></span>
<span><i class="fas fa-crown"></i></span>
</div>
</nav>
</header>

<section class="admin-page">

<div class="admin-header">
<h2>Manage Orders</h2>
<p>Track and update customer purchases.</p>
</div>

<div class="table-box">

<div class="table-head orders-grid">
<div>ID</div>
<div>Customer</div>
<div>Total</div>
<div>Status</div>
<div>Action</div>
</div>

<?php while($r = mysqli_fetch_assoc($q)){ ?>

<?php
$status = $r['status'];

if(!$status || $status == ''){
$status = 'Pending';
}
?>

<div class="table-row orders-grid">

<div>#<?php echo $r['id']; ?></div>

<div>
<strong><?php echo $r['full_name']; ?></strong><br>
<small><?php echo $r['email']; ?></small>
</div>

<div>
$<?php echo number_format($r['total_price'],2); ?>
</div>

<div>
<span class="status-badge status-<?php echo strtolower($status); ?>">
<?php echo $status; ?>
</span>
</div>

<div class="order-actions">

<a
href="orders.php?complete=<?php echo $r['id']; ?>"
class="complete-btn">
Complete
</a>

<a
href="orders.php?cancel=<?php echo $r['id']; ?>"
class="delete-btn">
Cancel
</a>

</div>

</div>

<?php } ?>

</div>

</section>

<footer>© 2026 Veloura Admin Panel</footer>

</body>
</html>