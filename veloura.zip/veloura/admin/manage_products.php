<?php
include '../config.php';

/* DELETE PRODUCT */
if(isset($_GET['delete'])){

$id = (int)$_GET['delete'];

mysqli_query($conn,"
DELETE FROM products
WHERE id='$id'
");

header("Location: manage_products.php");
exit();
}

/* GET PRODUCTS */
$q = mysqli_query($conn,"
SELECT * FROM products
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Products | Admin</title>

<link rel="stylesheet" href="../css/global.css">
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">
✨ ADMIN PANEL - PRODUCTS ✨
</section>

<header>

<h1>VELOURA</h1>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="add_product.php">Add Product</a>
<a href="manage_users.php">Users</a>
<a href="manage_products.php">Products</a>
<a href="orders.php">Orders</a>
<a href="../index.php">Website</a>
<a href="../logout.php">Logout</a>
</nav>

</header>

<section class="admin-page">

<div class="admin-header">
<h2>Manage Products</h2>
<p>Edit or remove products from your store.</p>
</div>

<div class="table-box">

<div class="table-head">
<div>ID</div>
<div>Product</div>
<div>Price</div>
<div>Actions</div>
</div>

<?php while($r=mysqli_fetch_assoc($q)){ ?>

<div class="table-row">

<div>#<?php echo $r['id']; ?></div>

<div style="display:flex;align-items:center;gap:14px;">

<img
src="../images/<?php echo $r['image']; ?>"
style="
width:60px;
height:60px;
object-fit:cover;
border-radius:14px;
background:#fff;
padding:4px;
">

<div>
<strong><?php echo $r['product_name']; ?></strong>
<br>
<small><?php echo substr($r['description'],0,45); ?>...</small>
</div>

</div>

<div>
$<?php echo number_format($r['price'],2); ?>
</div>

<div class="order-actions">

<a
href="edit_product.php?id=<?php echo $r['id']; ?>"
class="complete-btn">
Edit
</a>

<a
href="manage_products.php?delete=<?php echo $r['id']; ?>"
class="delete-btn"
onclick="return confirm('Delete this product?')">
Delete
</a>

</div>

</div>

<?php } ?>

</div>

</section>

<footer>
© 2026 Veloura Admin Panel
</footer>

</body>
</html>