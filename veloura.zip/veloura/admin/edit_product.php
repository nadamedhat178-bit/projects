<?php
include '../config.php';

/* GET PRODUCT ID */
if(!isset($_GET['id'])){
header("Location: manage_products.php");
exit();
}

$id = (int)$_GET['id'];

/* LOAD PRODUCT */
$q = mysqli_query($conn,"
SELECT * FROM products
WHERE id='$id'
");

$product = mysqli_fetch_assoc($q);

if(!$product){
header("Location: manage_products.php");
exit();
}

$success = '';
$error = '';

/* UPDATE PRODUCT */
if($_SERVER['REQUEST_METHOD'] == 'POST'){

$name  = mysqli_real_escape_string($conn,$_POST['name']);
$price = mysqli_real_escape_string($conn,$_POST['price']);
$desc  = mysqli_real_escape_string($conn,$_POST['description']);
$image = mysqli_real_escape_string($conn,$_POST['image']);

if($name == '' || $price == ''){

$error = "Please fill required fields.";

}else{

mysqli_query($conn,"
UPDATE products
SET
product_name='$name',
price='$price',
description='$desc',
image='$image'
WHERE id='$id'
");

$success = "Product updated successfully.";

$q = mysqli_query($conn,"
SELECT * FROM products
WHERE id='$id'
");

$product = mysqli_fetch_assoc($q);

}
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Product | Admin</title>

<link rel="stylesheet" href="../css/global.css">
<link rel="stylesheet" href="../css/auth.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">
✨ ADMIN PANEL - EDIT PRODUCT ✨
</section>

<header>

<h1>VELOURA</h1>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="add_product.php">Add Product</a>
<a href="manage_users.php">Users</a>
<a href="manage_products.php">Products</a>
<a href="orders.php">Orders</a>
<a href="../index.php">Website</a>
<a href="../logout.php">Logout</a>
</nav>

</header>

<section class="login-page">

<div class="login-box">

<div class="login-icon">
<i class="fas fa-pen"></i>
</div>

<h2>Edit Product</h2>
<p>Update your product details</p>

<?php if($error){ ?>
<div class="error-msg"><?php echo $error; ?></div>
<?php } ?>

<?php if($success){ ?>
<div class="success-msg"><?php echo $success; ?></div>
<?php } ?>

<form method="post">

<div class="input-group">
<i class="fas fa-gem"></i>
<input
type="text"
name="name"
value="<?php echo $product['product_name']; ?>"
required>
</div>

<div class="input-group">
<i class="fas fa-dollar-sign"></i>
<input
type="number"
step="0.01"
name="price"
value="<?php echo $product['price']; ?>"
required>
</div>

<div class="input-group">
<i class="fas fa-image"></i>
<input
type="text"
name="image"
value="<?php echo $product['image']; ?>">
</div>

<div class="input-group">
<i class="fas fa-align-left"></i>
<input
type="text"
name="description"
value="<?php echo $product['description']; ?>">
</div>

<?php if($product['image']){ ?>

<div style="margin:10px 0 18px;">
<img
src="../images/<?php echo $product['image']; ?>"
style="
width:120px;
height:120px;
object-fit:cover;
border-radius:20px;
background:#fff;
padding:8px;
box-shadow:0 10px 18px rgba(0,0,0,.06);
">
</div>

<?php } ?>

<button type="submit" class="login-btn">
Save Changes
</button>

</form>

<div class="login-links">
<a href="manage_products.php">← Back</a>
<a href="../product.php?id=<?php echo $id; ?>">View Product</a>
</div>

</div>

</section>

<footer>
© 2026 Veloura Admin Panel
</footer>

</body>
</html>