<?php
include '../config.php';

/* OPTIONAL ADMIN CHECK
if(!isset($_SESSION['admin'])){
header("Location:login.php");
exit();
}
*/
if(!isset($_SESSION['admin_id'])){
header("Location: ../index.php");
exit();
}
$msg = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){

$name = mysqli_real_escape_string($conn,$_POST['name']);
$price = mysqli_real_escape_string($conn,$_POST['price']);
$desc = mysqli_real_escape_string($conn,$_POST['description']);
$image = mysqli_real_escape_string($conn,$_POST['image']);

if($name == '' || $price == ''){

$error = "Please fill all required fields.";

}else{

mysqli_query($conn,"
INSERT INTO products
(product_name,price,description,image)
VALUES
('$name','$price','$desc','$image')
");

$msg = "Product added successfully.";

}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Product | Veloura Admin</title>

<link rel="stylesheet" href="../css/global.css">
<link rel="stylesheet" href="../css/auth.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ VELOURA ADMIN PANEL ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="add_product.php">Add Product</a>
<a href="manage_users.php">Users</a>
<a href="manage_products.php">Products</a>
<a href="orders.php">Orders</a>
<a href="../index.php">Website</a>
<a href="../logout.php">Logout</a>


<div class="icons">
<span><i class="fas fa-box"></i></span>
<span><i class="fas fa-chart-line"></i></span>
<span><i class="fas fa-crown"></i></span>
</div>
</nav>
</header>

<section class="login-page">

<div class="login-box">

<div class="login-icon">
<i class="fas fa-plus-circle"></i>
</div>

<h2>Add Product</h2>
<p>Create a new luxury item for the store</p>

<?php if($error){ ?>
<div class="error-msg"><?php echo $error; ?></div>
<?php } ?>

<?php if($msg){ ?>
<div class="success-msg"><?php echo $msg; ?></div>
<?php } ?>

<form method="post">

<div class="input-group">
<i class="fas fa-gem"></i>
<input type="text" name="name" placeholder="Product Name" required>
</div>

<div class="input-group">
<i class="fas fa-dollar-sign"></i>
<input type="number" step="0.01" name="price" placeholder="Price" required>
</div>

<div class="input-group">
<i class="fas fa-image"></i>
<input type="text" name="image" placeholder="Image File Name (example: bag1.jpg)">
</div>

<div class="input-group">
<i class="fas fa-align-left"></i>
<input type="text" name="description" placeholder="Short Description">
</div>

<button type="submit" class="login-btn">
Add Product
</button>

</form>

<div class="login-links">
<a href="manage_products.php">Manage Products</a>
<a href="../index.php">View Store</a>
</div>

</div>

</section>

<footer>© 2026 Veloura Admin Panel</footer>

</body>
</html>