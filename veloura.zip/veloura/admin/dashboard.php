<?php
include '../config.php';

/* OPTIONAL ADMIN CHECK
if(!isset($_SESSION['admin'])){
header("Location:login.php");
exit();
}
*/

$p_count = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM products"))['c'];
$u_count = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM users"))['c'];
$o_count = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM orders"))['c'];

$sales = mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) t FROM orders"))['t'];
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard | Veloura Admin</title>

<link rel="stylesheet" href="../css/global.css">
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ VELOURA ADMIN DASHBOARD ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="add_product.php">Add Product</a>
<a href="manage_users.php">Users</a>
<a href="manage_products.php">Products</a>
<a href="orders.php">Orders</a>
<a href="../index.php">Website</a>
<a href="../logout.php">Logout</a>

<div class="icons">
<span><i class="fas fa-crown"></i></span>
<span><i class="fas fa-chart-line"></i></span>
<span><i class="fas fa-shield-alt"></i></span>
</div>
</nav>
</header>

<section class="admin-page">

<div class="admin-header">
<h2>Admin Dashboard</h2>
<p>Manage products, users and store performance.</p>
</div>

<div class="admin-stats">

<div class="admin-card">
<i class="fas fa-box-open"></i>
<h3><?php echo $p_count; ?></h3>
<p>Total Products</p>
</div>

<div class="admin-card">
<i class="fas fa-users"></i>
<h3><?php echo $u_count; ?></h3>
<p>Total Users</p>
</div>

<div class="admin-card">
<i class="fas fa-shopping-bag"></i>
<h3><?php echo $o_count; ?></h3>
<p>Total Orders</p>
</div>

<div class="admin-card">
<i class="fas fa-dollar-sign"></i>
<h3>$<?php echo number_format($sales,2); ?></h3>
<p>Total Sales</p>
</div>

</div>

<div class="admin-actions">

<a href="add_product.php" class="btn">Add Product</a>
<a href="manage_users.php" class="btn">Manage Users</a>
<a href="orders.php" class="btn">Manage Orders</a>
<a href="manage_products.php" class="btn">Manage Products</a>
<a href="../shop.php" class="btn">View Store</a>

</div>

</section>

<footer>© 2026 Veloura Admin Panel</footer>

</body>
</html>