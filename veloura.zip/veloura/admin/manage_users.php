<?php
include '../config.php';

/* OPTIONAL ADMIN CHECK
if(!isset($_SESSION['admin'])){
header("Location:login.php");
exit();
}
*/

/* DELETE USER */
if(isset($_GET['delete'])){

$id = (int)$_GET['delete'];

mysqli_query($conn,"DELETE FROM users WHERE id='$id'");
header("Location:manage_users.php");
exit();
}

$users = mysqli_query($conn,"
SELECT * FROM users
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Users | Veloura Admin</title>

<link rel="stylesheet" href="../css/global.css">
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ USER MANAGEMENT PANEL ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="dashboard.php">Dashboard</a>
<a href="add_product.php">Add Product</a>
<a href="manage_users.php">Users</a>
<a href="manage_products.php">Products</a>
<a href="orders.php">Orders</a>
<a href="../index.php">Website</a>
<a href="../logout.php">Logout</a>

<div class="icons">
<span><i class="fas fa-users"></i></span>
<span><i class="fas fa-user-shield"></i></span>
<span><i class="fas fa-crown"></i></span>
</div>
</nav>
</header>

<section class="admin-page">

<div class="admin-header">
<h2>Manage Users</h2>
<p>View and manage registered customers.</p>
</div>

<div class="table-box">

<div class="table-head">
<div>ID</div>
<div>Name</div>
<div>Email</div>
<div>Action</div>
</div>

<?php while($u = mysqli_fetch_assoc($users)){ ?>

<div class="table-row">
<div>#<?php echo $u['id']; ?></div>
<div><?php echo $u['full_name']; ?></div>
<div><?php echo $u['email']; ?></div>
<div>
<a
href="manage_users.php?delete=<?php echo $u['id']; ?>"
class="delete-btn"
onclick="return confirm('Delete this user?')">
Delete
</a>
</div>
</div>

<?php } ?>

</div>

</section>

<footer>© 2026 Veloura Admin Panel</footer>

</body>
</html>