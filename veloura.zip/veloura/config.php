<?php
$conn = mysqli_connect('localhost','root','','veloura');
session_start();
if(!$conn){ die('Connection failed'); }
$isLoggedIn = isset($_SESSION['user_id']);
?>