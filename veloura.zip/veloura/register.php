<?php
include 'config.php';

$msg = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){

$name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$password = mysqli_real_escape_string($conn,$_POST['password']);

$check = mysqli_query($conn,"SELECT id FROM users WHERE email='$email'");

if(mysqli_num_rows($check) > 0){

$error = "This email is already registered.";

}else{

mysqli_query($conn,"INSERT INTO users(full_name,email,password) VALUES('$name','$email','$password')");
$msg = "Registration successful. You can now login.";

}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Veloura Register</title>
<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/auth.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ JOIN THE VELOURA WORLD ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<?php if($isLoggedIn){ ?>
<a href="favorites.php">Favorites</a>

<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>
<a href="cart.php">Cart</a>

<div class="icons">
<span><i class="fas fa-search"></i></span>
<span><i class="far fa-heart"></i></span>
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="far fa-user"></i></span>
</div>
</nav>
</header>

<section class="login-page">

<div class="login-box">

<div class="login-icon">
<i class="fas fa-user-plus"></i>
</div>

<h2>Create Account</h2>
<p>Register and discover timeless elegance</p>

<?php if($error){ ?>
<div class="error-msg"><?php echo $error; ?></div>
<?php } ?>

<?php if($msg){ ?>
<div class="success-msg"><?php echo $msg; ?></div>
<?php } ?>

<form method="post">

<div class="input-group">
<i class="fas fa-user"></i>
<input type="text" name="name" placeholder="Full Name" required>
</div>

<div class="input-group">
<i class="fas fa-envelope"></i>
<input type="email" name="email" placeholder="Email Address" required>
</div>

<div class="input-group">
<i class="fas fa-lock"></i>
<input type="password" name="password" placeholder="Password" required>
</div>

<button type="submit" class="login-btn">Create Account</button>

</form>

<div class="login-links">
<a href="login.php">Already have an account?</a>
<a href="shop.php">Continue Shopping</a>
</div>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>