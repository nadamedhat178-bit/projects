<!-- favorites.php -->

<?php
include 'config.php';

if(!isset($_SESSION['user_id'])){
header("Location:login.php");
exit();
}

$user = $_SESSION['user_id'];

if(isset($_GET['remove'])){

$id = (int)$_GET['remove'];

mysqli_query($conn,"
DELETE FROM favorites
WHERE user_id='$user' AND product_id='$id'
");

header("Location:favorites.php");
exit();
}

$q = mysqli_query($conn,"
SELECT products.*
FROM favorites
JOIN products ON products.id = favorites.product_id
WHERE favorites.user_id='$user'
ORDER BY favorites.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Favorites | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/shop.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ YOUR FAVORITES ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<a href="favorites.php">Favorites</a>
<a href="cart.php">Cart</a>
<a href="profile.php">Profile</a>
</nav>

</header>

<section class="shop-page">

<div class="shop-header">
<h2>Saved Luxury Pieces</h2>
<p>Your favorite timeless selections.</p>
</div>

<div class="grid">

<?php while($r = mysqli_fetch_assoc($q)){ ?>

<div class="card">

<form method="get" class="fav-form">

<input
type="hidden"
name="remove"
value="<?php echo $r['id']; ?>">

<button type="submit" class="heart">
<i class="fas fa-heart"></i>
</button>

</form>

<img src="images/<?php echo $r['image']; ?>">

<h3><?php echo $r['product_name']; ?></h3>

<p>$<?php echo number_format($r['price'],2); ?></p>

<a href="product.php?id=<?php echo $r['id']; ?>">
View Product
</a>

</div>

<?php } ?>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>