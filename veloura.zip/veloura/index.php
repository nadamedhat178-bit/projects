<?php
include 'config.php';

/* USER OR ADMIN LOGIN */
$isUserLoggedIn  = isset($_SESSION['user_id']);
$isAdminLoggedIn = isset($_SESSION['admin_id']);

$isLoggedIn = $isUserLoggedIn || $isAdminLoggedIn;
$user = $isUserLoggedIn ? (int)$_SESSION['user_id'] : 0;

/* TOGGLE FAVORITE */
if(isset($_GET['fav']) && $isLoggedIn){

$pid = (int)$_GET['fav'];

$check = mysqli_query($conn,"
SELECT id FROM favorites
WHERE user_id='$user' AND product_id='$pid'
");

if(mysqli_num_rows($check) > 0){

mysqli_query($conn,"
DELETE FROM favorites
WHERE user_id='$user' AND product_id='$pid'
");

}else{

mysqli_query($conn,"
INSERT INTO favorites(user_id,product_id)
VALUES('$user','$pid')
");

}

header("Location: index.php");
exit();
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Veloura</title>
<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/home.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<script defer src="script.js"></script>

</head>
<body>

<section class="topbar">
✨ FREE SHIPPING ON ORDERS OVER $100 ✨
</section>

<header>

<h1>VELOURA</h1>

<nav>

<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<a href="cart.php">Cart</a>
<?php if($isAdminLoggedIn){ ?>
<a href="admin/dashboard.php">Admin Dashboard</a>
<?php } ?>

<?php if($isLoggedIn){ ?>

<a href="favorites.php">Favorites</a>
<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>


<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>

<div class="icons">

<span onclick="location.href='shop.php'">
<i class="fas fa-search"></i>
</span>

<?php if($isLoggedIn){ ?>

<span onclick="location.href='favorites.php'">
<i class="far fa-heart"></i>
</span>

<span onclick="location.href='profile.php'">
<i class="far fa-user"></i>
</span>

<?php }else{ ?>

<span onclick="location.href='login.php'">
<i class="far fa-heart"></i>
</span>

<span onclick="location.href='login.php'">
<i class="far fa-user"></i>
</span>

<?php } ?>

<span onclick="location.href='cart.php'">
<i class="fas fa-shopping-bag"></i>
</span>

</div>

</nav>

</header>

<section class="hero slider">

<div class="sparkle"></div>
<div class="sparkle"></div>
<div class="sparkle"></div>

<div class="slide active">
<h2>Elevate Every Moment</h2>
<p>Luxury accessories designed for the modern woman.</p>
<a class="btn" href="shop.php">Shop Now</a>
</div>

<div class="slide">
<h2>Timeless Beauty</h2>
<p>Exclusive collections with elegance and shine.</p>
<a class="btn" href="shop.php">Explore</a>
</div>

<div class="slide">
<h2>Veloura Signature</h2>
<p>Premium bags, jewelry, watches & perfumes.</p>
<a class="btn" href="shop.php">View Collection</a>
</div>

<div class="dots">
<span class="dot active"></span>
<span class="dot"></span>
<span class="dot"></span>
</div>

</section>

<section class="categories">
<div><span>📿</span>Necklaces</div>
<div><span>🪄</span>Bracelets</div>
<div><span>💍</span>Rings</div>
<div><span>👜</span>Handbags</div>
<div><span>⌚</span>Watches</div>
</section>

<h2>Featured Products</h2>

<div class="grid">

<?php
$q = mysqli_query($conn,"
SELECT * FROM products
ORDER BY id DESC
LIMIT 6
");

while($r = mysqli_fetch_assoc($q)){
?>

<?php
$fav = 0;

if($isLoggedIn){

$pid = $r['id'];

$f = mysqli_query($conn,"
SELECT id FROM favorites
WHERE user_id='$user' AND product_id='$pid'
");

$fav = mysqli_num_rows($f);
}
?>

<div class="card">

<?php if($isLoggedIn){ ?>

<form method="get" class="fav-form">

<input
type="hidden"
name="fav"
value="<?php echo $r['id']; ?>">

<button type="submit" class="heart">

<?php if($fav){ ?>
<i class="fas fa-heart"></i>
<?php }else{ ?>
<i class="far fa-heart"></i>
<?php } ?>

</button>

</form>

<?php }else{ ?>

<button
type="button"
onclick="location.href='login.php'"
class="heart">

<i class="far fa-heart"></i>

</button>

<?php } ?>

<img
src="images/<?php echo $r['image']; ?>"
alt="<?php echo $r['product_name']; ?>">

<h3><?php echo $r['product_name']; ?></h3>

<p>
$<?php echo number_format($r['price'],2); ?>
</p>

<a href="product.php?id=<?php echo $r['id']; ?>">
View Product
</a>

</div>

<?php } ?>

</div>

<section class="benefits">
<div>💎 Premium Quality</div>
<div>🚚 Free Shipping</div>
<div>🔒 Secure Payment</div>
<div>🎧 24/7 Support</div>
</section>

<footer>
© 2026 Veloura Luxury Accessories
</footer>

</body>
</html>