<?php
include 'config.php';

$isLoggedIn = isset($_SESSION['user_id']);
$user = $isLoggedIn ? (int)$_SESSION['user_id'] : 0;

/* SEARCH + CATEGORY */
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$cat    = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;

/* TOGGLE FAVORITE */
if(isset($_GET['fav']) && $isLoggedIn){

$pid = (int)$_GET['fav'];

$check = mysqli_query($conn,"
SELECT id FROM favorites
WHERE user_id='$user'
AND product_id='$pid'
");

if(mysqli_num_rows($check) > 0){

mysqli_query($conn,"
DELETE FROM favorites
WHERE user_id='$user'
AND product_id='$pid'
");

}else{

mysqli_query($conn,"
INSERT INTO favorites(user_id,product_id)
VALUES('$user','$pid')
");

}

/* KEEP FILTERS AFTER FAVORITE */
$url = "shop.php?";

if($search != ''){
$url .= "search=" . urlencode($search) . "&";
}

if($cat > 0){
$url .= "cat=$cat";
}

header("Location: $url");
exit();
}

/* GET CATEGORIES */
$cats = mysqli_query($conn,"
SELECT * FROM categories
ORDER BY category_name  ASC
");

/* PRODUCT QUERY */
$sql = "
SELECT products.*, categories.category_name AS category_name
FROM products
LEFT JOIN categories
ON categories.id = products.category_id
WHERE 1
";

if($cat > 0){
$sql .= " AND products.category_id='$cat' ";
}

if($search != ''){

$safe = mysqli_real_escape_string($conn,$search);

$sql .= "
AND (
products.product_name LIKE '%$safe%'
OR products.description LIKE '%$safe%'
OR categories.category_name LIKE '%$safe%'
)
";
}

$sql .= " ORDER BY products.id DESC ";

$q = mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Shop | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/shop.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ DISCOVER OUR LUXURY COLLECTION ✨</section>

<header>

<h1>VELOURA</h1>

<nav>

<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<a href="cart.php">Cart</a>

<?php if($isLoggedIn){ ?>

<a href="favorites.php">Favorites</a>
<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>

<div class="icons">

<span onclick="location.href='shop.php'">
<i class="fas fa-search"></i>
</span>

<?php if($isLoggedIn){ ?>

<span onclick="location.href='favorites.php'">
<i class="far fa-heart"></i>
</span>

<span onclick="location.href='profile.php'">
<i class="far fa-user"></i>
</span>

<?php }else{ ?>

<span onclick="location.href='login.php'">
<i class="far fa-heart"></i>
</span>

<span onclick="location.href='login.php'">
<i class="far fa-user"></i>
</span>

<?php } ?>

<span onclick="location.href='cart.php'">
<i class="fas fa-shopping-bag"></i>
</span>

</div>

</nav>

</header>

<section class="shop-page">

<div class="shop-header">
<h2>Luxury Collection</h2>
<p>Elegant accessories crafted for timeless beauty.</p>
</div>

<!-- SEARCH -->
<form method="get" class="shop-search" style="text-align:center;margin-bottom:25px;">

<input
type="text"
name="search"
placeholder="Search products..."
value="<?php echo htmlspecialchars($search); ?>"
style="
padding:14px 18px;
width:320px;
max-width:90%;
border:none;
border-radius:35px;
box-shadow:0 8px 18px rgba(0,0,0,.06);
outline:none;
">

<?php if($cat > 0){ ?>
<input type="hidden" name="cat" value="<?php echo $cat; ?>">
<?php } ?>

<button class="filter-btn active" style="margin-left:10px;">
Search
</button>

</form>

<!-- FILTERS -->
<div class="shop-filters">

<!-- ALL -->
<form method="get">

<?php if($search){ ?>
<input type="hidden" name="search"
value="<?php echo htmlspecialchars($search); ?>">
<?php } ?>

<button
type="submit"
class="filter-btn <?php if($cat==0) echo 'active'; ?>">
All
</button>

</form>

<?php while($c = mysqli_fetch_assoc($cats)){ ?>

<form method="get">

<input
type="hidden"
name="cat"
value="<?php echo $c['id']; ?>">

<?php if($search){ ?>
<input
type="hidden"
name="search"
value="<?php echo htmlspecialchars($search); ?>">
<?php } ?>

<button
type="submit"
class="filter-btn <?php if($cat==$c['id']) echo 'active'; ?>">

<?php echo $c['category_name']; ?>

</button>

</form>

<?php } ?>

</div>

<div class="grid">

<?php while($r = mysqli_fetch_assoc($q)){ ?>

<?php
$fav = 0;

if($isLoggedIn){

$pid = $r['id'];

$f = mysqli_query($conn,"
SELECT id FROM favorites
WHERE user_id='$user'
AND product_id='$pid'
");

$fav = mysqli_num_rows($f);
}
?>

<div class="card">

<?php if($isLoggedIn){ ?>

<form method="get" class="fav-form">

<input
type="hidden"
name="fav"
value="<?php echo $r['id']; ?>">

<?php if($cat > 0){ ?>
<input type="hidden" name="cat" value="<?php echo $cat; ?>">
<?php } ?>

<?php if($search){ ?>
<input
type="hidden"
name="search"
value="<?php echo htmlspecialchars($search); ?>">
<?php } ?>

<button type="submit" class="heart">

<?php if($fav){ ?>
<i class="fas fa-heart"></i>
<?php }else{ ?>
<i class="far fa-heart"></i>
<?php } ?>

</button>

</form>

<?php }else{ ?>

<button
type="button"
onclick="location.href='login.php'"
class="heart">

<i class="far fa-heart"></i>

</button>

<?php } ?>
<img
src="images/<?php echo $r['image']; ?>"
alt="<?php echo $r['product_name']; ?>">

<h3><?php echo $r['product_name']; ?></h3>

<p>$<?php echo number_format($r['price'],2); ?></p>

<p style="padding:0 18px 12px;color:#777;font-size:14px;">
<?php echo $r['category_name']; ?>
</p>

<a href="product.php?id=<?php echo $r['id']; ?>">
View Product
</a>

</div>

<?php } ?>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>