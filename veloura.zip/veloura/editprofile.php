<?php
include 'config.php';

if(!isset($_SESSION['user_id'])){
header("Location: login.php");
exit();
}

$user_id = (int)$_SESSION['user_id'];
$success = '';
$error = '';

$q = mysqli_query($conn,"SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($q);

if($_SERVER['REQUEST_METHOD'] == 'POST'){

$name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$password = trim($_POST['password']);

$check = mysqli_query($conn,"
SELECT id FROM users
WHERE email='$email'
AND id != '$user_id'
");

if(mysqli_num_rows($check) > 0){

$error = "Email already in use.";

}else{

if($password != ''){

$password = mysqli_real_escape_string($conn,$password);

mysqli_query($conn,"
UPDATE users
SET full_name='$name',
email='$email',
password='$password'
WHERE id='$user_id'
");

}else{

mysqli_query($conn,"
UPDATE users
SET full_name='$name',
email='$email'
WHERE id='$user_id'
");

}

$success = "Profile updated successfully.";

$q = mysqli_query($conn,"SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($q);

}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Profile | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/auth.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ MANAGE YOUR ACCOUNT ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<?php if($isAdminLoggedIn){ ?>
<a href="admin/dashboard.php">Admin Dashboard</a>
<?php } ?>
<?php if($isLoggedIn){ ?>
<a href="favorites.php">Favorites</a>

<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>
<a href="cart.php">Cart</a>

<div class="icons">
<span><i class="fas fa-search"></i></span>
<span><i class="far fa-heart"></i></span>
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="far fa-user"></i></span>
</div>
</nav>
</header>

<section class="login-page">

<div class="login-box">

<div class="login-icon">
<i class="fas fa-user-edit"></i>
</div>

<h2>Edit Profile</h2>
<p>Update your Veloura account details</p>

<?php if($error){ ?>
<div class="error-msg"><?php echo $error; ?></div>
<?php } ?>

<?php if($success){ ?>
<div class="success-msg"><?php echo $success; ?></div>
<?php } ?>

<form method="post">

<div class="input-group">
<i class="fas fa-user"></i>
<input
type="text"
name="name"
value="<?php echo $user['full_name']; ?>"
required>
</div>

<div class="input-group">
<i class="fas fa-envelope"></i>
<input
type="email"
name="email"
value="<?php echo $user['email']; ?>"
required>
</div>

<div class="input-group">
<i class="fas fa-lock"></i>
<input
type="password"
name="password"
placeholder="New Password (optional)">
</div>

<button type="submit" class="login-btn">
Save Changes
</button>

</form>

<div class="login-links">
<a href="profile.php">← Back to Profile</a>
<a href="shop.php">Shop</a>
</div>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>