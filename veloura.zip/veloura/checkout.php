<?php
include 'config.php';

if(!isset($_SESSION['user_id'])){
header("Location:login.php");
exit();
}

if(empty($_SESSION['cart'])){
header("Location:cart.php");
exit();
}

$total = 0;
$items = [];

foreach($_SESSION['cart'] as $id => $qty){

$id = (int)$id;
$qty = (int)$qty;

$q = mysqli_query($conn,"SELECT * FROM products WHERE id=$id");
$p = mysqli_fetch_assoc($q);

if($p){

$sub = $p['price'] * $qty;
$total += $sub;

$items[] = [
'name' => $p['product_name'],
'image' => $p['image'],
'price' => $p['price'],
'qty' => $qty,
'sub' => $sub
];

}
}

$order_done = false;

if(isset($_POST['place_order'])){

mysqli_query($conn,"
INSERT INTO orders(user_id,total_price)
VALUES('".$_SESSION['user_id']."','$total')
");

unset($_SESSION['cart']);
$order_done = true;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Checkout | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/checkout.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ SECURE LUXURY CHECKOUT ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<?php if($isLoggedIn){ ?>
<a href="favorites.php">Favorites</a>

<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>
<a href="cart.php">Cart</a>

<div class="icons">
<span><i class="fas fa-search"></i></span>
<span><i class="far fa-heart"></i></span>
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="far fa-user"></i></span>
</div>
</nav>
</header>

<section class="checkout-page">

<?php if($order_done){ ?>

<div class="success-box">
<i class="fas fa-check-circle"></i>
<h2>Order Placed Successfully</h2>
<p>Thank you for shopping with Veloura.</p>

<a href="shop.php" class="btn">Continue Shopping</a>
</div>

<?php }else{ ?>

<div class="checkout-wrap">

<div class="checkout-left">

<h2>Order Summary</h2>

<?php foreach($items as $item){ ?>

<div class="checkout-item">

<img src="images/<?php echo $item['image']; ?>">

<div class="checkout-info">
<h3><?php echo $item['name']; ?></h3>
<p>$<?php echo $item['price']; ?> × <?php echo $item['qty']; ?></p>
</div>

<div class="checkout-sub">
$<?php echo number_format($item['sub'],2); ?>
</div>

</div>

<?php } ?>

</div>

<div class="checkout-right">

<h2>Payment</h2>

<div class="pay-box">
<div><span>Subtotal</span> <strong>$<?php echo number_format($total,2); ?></strong></div>
<div><span>Shipping</span> <strong>Free</strong></div>
<div><span>Total</span> <strong>$<?php echo number_format($total,2); ?></strong></div>
</div>

<div class="luxury-points">
<div>🔒 100% Secure Checkout</div>
<div>🚚 Fast Delivery</div>
<div>💎 Premium Packaging</div>
</div>

<form method="post">
<button name="place_order" class="login-btn pay-btn">
<i class="fas fa-lock"></i> Place Order
</button>
</form>

</div>

</div>

<?php } ?>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>