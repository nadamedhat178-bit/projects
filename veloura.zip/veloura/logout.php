<?php
include 'config.php';

/* REMOVE ALL SESSION DATA */
$_SESSION = [];

/* DESTROY SESSION */
session_destroy();

/* REDIRECT TO HOME */
header("Location: index.php");
exit();
?>