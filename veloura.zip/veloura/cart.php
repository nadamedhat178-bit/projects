<?php
include 'config.php';

/* ADD TO CART */
if(isset($_POST['id'])){

$id  = (int)$_POST['id'];
$qty = (int)$_POST['qty'];

if($qty < 1){ $qty = 1; }

$_SESSION['cart'][$id] = $qty;
}

/* REMOVE ITEM */
if(isset($_GET['remove'])){
$id = (int)$_GET['remove'];
unset($_SESSION['cart'][$id]);
}

/* UPDATE QTY */
if(isset($_POST['update_cart'])){

foreach($_POST['qty'] as $id => $qty){

$id  = (int)$id;
$qty = (int)$qty;

if($qty <= 0){
unset($_SESSION['cart'][$id]);
}else{
$_SESSION['cart'][$id] = $qty;
}

}
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Cart | Veloura</title>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/cart.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ YOUR LUXURY CART ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>

<?php if($isLoggedIn){ ?>
<a href="favorites.php">Favorites</a>

<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>

<a href="cart.php">Cart</a>

<div class="icons">
<span><i class="fas fa-search"></i></span>
<span><i class="far fa-heart"></i></span>
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="far fa-user"></i></span>
</div>
</nav>
</header>

<section class="cart-page">

<h2>Your Shopping Bag</h2>

<?php if(empty($_SESSION['cart'])){ ?>

<div class="empty-cart">
<i class="fas fa-shopping-bag"></i>
<h3>Your cart is empty</h3>
<p>Discover timeless elegance in our collection.</p>
<a href="shop.php" class="btn">Shop Now</a>
</div>

<?php }else{ ?>

<form method="post">

<div class="cart-wrap">

<div class="cart-left">

<?php
$total = 0;

foreach($_SESSION['cart'] as $id => $qty){

$q = mysqli_query($conn,"SELECT * FROM products WHERE id=$id");
$p = mysqli_fetch_assoc($q);

if(!$p){ continue; }

$sub = $p['price'] * $qty;
$total += $sub;
?>

<div class="cart-item">

<img src="images/<?php echo $p['image']; ?>" alt="<?php echo $p['product_name']; ?>">

<div class="cart-info">
<h3><?php echo $p['product_name']; ?></h3>
<p>$<?php echo $p['price']; ?></p>

<a href="cart.php?remove=<?php echo $p['id']; ?>" class="remove-link">
Remove
</a>
</div>

<div class="cart-qty">
<input type="number" name="qty[<?php echo $p['id']; ?>]" value="<?php echo $qty; ?>" min="1">
</div>

<div class="cart-sub">
$<?php echo number_format($sub,2); ?>
</div>

</div>

<?php } ?>

<button name="update_cart" class="update-btn">
<i class="fas fa-sync-alt"></i> Update Cart
</button>

</div>

<div class="cart-right">

<h2>Summary</h2>

<div class="pay-box">
<div><span>Subtotal</span><strong>$<?php echo number_format($total,2); ?></strong></div>
<div><span>Shipping</span><strong>Free</strong></div>
<div><span>Total</span><strong>$<?php echo number_format($total,2); ?></strong></div>
</div>

<div class="luxury-points">
<div>🚚 Fast Shipping</div>
<div>🔒 Secure Checkout</div>
<div>💎 Premium Packaging</div>
</div>

<a href="checkout.php" class="btn cart-checkout-btn">
Proceed To Checkout
</a>

</div>

</div>

</form>

<?php } ?>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>