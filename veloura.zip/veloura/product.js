function plusQty(){
let q = document.getElementById('qty');
q.value = parseInt(q.value) + 1;
}

function minusQty(){
let q = document.getElementById('qty');
if(parseInt(q.value) > 1){
q.value = parseInt(q.value) - 1;
}
}