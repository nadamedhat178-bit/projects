<?php
include 'config.php';

$error = '';

if($_POST){

$email = mysqli_real_escape_string($conn,$_POST['email']);
$pass  = mysqli_real_escape_string($conn,$_POST['password']);

/* CHECK ADMINS FIRST */
$q = mysqli_query($conn,"
SELECT * FROM admin
WHERE email='$email'
AND password='$pass'
");

if(mysqli_num_rows($q)){

$a = mysqli_fetch_assoc($q);

$_SESSION['admin_id']   = $a['id'];

header("Location: admin/dashboard.php");
exit();
}

/* CHECK USERS */
$q2 = mysqli_query($conn,"
SELECT * FROM users
WHERE email='$email'
AND password='$pass'
");

if(mysqli_num_rows($q2)){

$u = mysqli_fetch_assoc($q2);

$_SESSION['user_id']   = $u['id'];

header("Location: index.php");
exit();
}

$error = "Invalid email or password.";

}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Veloura Login</title>
<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/auth.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<body>

<section class="topbar">✨ WELCOME BACK TO VELOURA ✨</section>

<header>
<h1>VELOURA</h1>

<nav>
<a href="index.php">Home</a>
<a href="shop.php">Shop</a>
<?php if($isLoggedIn){ ?>
<a href="favorites.php">Favorites</a>

<a href="profile.php">Profile</a>
<a href="logout.php">Logout</a>

<?php }else{ ?>

<a href="login.php">Login</a>
<a href="register.php">Register</a>

<?php } ?>
<a href="cart.php">Cart</a>

<div class="icons">
<span><i class="fas fa-search"></i></span>
<span><i class="far fa-heart"></i></span>
<span><i class="fas fa-shopping-bag"></i></span>
<span><i class="far fa-user"></i></span>
</div>
</nav>
</header>

<section class="login-page">

<div class="login-box">

<div class="login-icon">
<i class="fas fa-user-circle"></i>
</div>

<h2>Welcome Back</h2>
<p>Login to your Veloura account</p>

<?php if($error){ ?>
<div class="error-msg"><?php echo $error; ?></div>
<?php } ?>

<form method="post">

<div class="input-group">
<i class="fas fa-envelope"></i>
<input type="email" name="email" placeholder="Email Address" required>
</div>

<div class="input-group">
<i class="fas fa-lock"></i>
<input type="password" name="password" placeholder="Password" required>
</div>

<button type="submit" class="login-btn">Login</button>

</form>

<div class="login-links">
<a href="#">Forgot Password?</a>
<a href="register.php">Create Account</a>
</div>

</div>

</section>

<footer>© 2026 Veloura Luxury Accessories</footer>

</body>
</html>