import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BMIServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String w = request.getParameter("weight");
        String h = request.getParameter("height");

       
        double weight = Double.parseDouble(w);
        double height = Double.parseDouble(h);

        double bmi = weight / (height * height);

        String category = "";

        if (bmi < 18.5) {
            category = "Underweight";
        } else if (bmi < 25) {
            category = "Normal (healthy weight)";
        } else if (bmi < 30) {
            category = "Overweight";
        } else {
            category = "Obese";
        }

        out.println("<html><body>");
        out.println("<h2>Result</h2>");
        out.println("<p>Your BMI is: " + bmi + "</p>");
        out.println("<p>Category: " + category + "</p>");
        out.println("<a href='index.html'>Back</a>");
        out.println("</body></html>");
    }
}